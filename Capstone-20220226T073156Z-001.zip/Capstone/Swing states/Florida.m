yyaxis left
plot(capstonedata.Year(53:58),capstonedata.Percentrepublicanvote(53:58),capstonedata.Year(53:58),capstonedata.Percentdemocratvote(53:58));
yyaxis right
plot(capstonedata.Year(53:58),capstonedata.Jobchange(53:58));
legend("Percent Republican vote", "Percent Democrat vote","Job change")
title("Florida")
xlabel("Year")