yyaxis left
plot(capstonedata.Year(131:136),capstonedata.Percentrepublicanvote(131:136),capstonedata.Year(131:136),capstonedata.Percentdemocratvote(131:136));
yyaxis right
plot(capstonedata.Year(131:136),capstonedata.Jobchange(131:136));
legend("Percent Republican vote", "Percent Democrat vote","Job change")
title("Michigan")
xlabel("Year")