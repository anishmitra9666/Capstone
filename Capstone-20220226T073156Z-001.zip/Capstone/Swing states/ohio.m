yyaxis left
plot(capstonedata.Year(209:214),capstonedata.Percentrepublicanvote(209:214),capstonedata.Year(209:214),capstonedata.Percentdemocratvote(209:214));
yyaxis right
plot(capstonedata.Year(209:214),capstonedata.Jobchange(209:214));
legend("Percent Republican vote", "Percent Democrat vote","Job change")
title("Ohio")
xlabel("Year")