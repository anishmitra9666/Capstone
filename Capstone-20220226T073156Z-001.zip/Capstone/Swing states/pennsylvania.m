yyaxis left
plot(capstonedata.Year(227:232),capstonedata.Percentrepublicanvote(227:232),capstonedata.Year(227:232),capstonedata.Percentdemocratvote(227:232));
yyaxis right
plot(capstonedata.Year(227:232),capstonedata.Jobchange(227:232));
legend("Percent Republican vote", "Percent Democrat vote","Job change")
title("Pennsylvania")
xlabel("Year")